https://archive.ics.uci.edu/ml/datasets/abalone

Lopez-Paz, D., Muandet, K., Schölkopf, B., & Tolstikhin, I. (2015, June). Towards a
learning theory of cause-effect inference. In International Conference on Machine
Learning (pp. 1452-1461). PMLR.