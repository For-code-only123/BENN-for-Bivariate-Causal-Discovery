https://archive.ics.uci.edu/ml/datasets/Algerian+Forest+Fires+Dataset++

For some ground truth:

https://www.nwcg.gov/publications/pms437/cffdrs/fire-weather-index-system